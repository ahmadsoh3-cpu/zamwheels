interface Vehicle {
  id: number
  price: string
  title: string
  details: string
  location: string
  time: string
  image: string
  category: string
  featured?: boolean
  urgent?: boolean
}

interface UserProfile {
  name: string
  email: string
  phone: string
  avatar: string
  verified: boolean
  rating: number
  reviewCount: number
  memberSince: string
  listingsCount: number
  soldCount: number
  viewsCount: string
}

interface SavedSearch {
  id: string
  query: string
  filters: Record<string, any>
  createdAt: string
}

// Storage keys
const STORAGE_KEYS = {
  FAVORITES: "zamwheels_favorites",
  USER_PROFILE: "zamwheels_user_profile",
  MY_LISTINGS: "zamwheels_my_listings",
  SAVED_SEARCHES: "zamwheels_saved_searches",
  VEHICLES: "zamwheels_vehicles",
  MESSAGES: "zamwheels_messages",
  NOTIFICATIONS: "zamwheels_notifications",
}

// Generic storage functions
export const storage = {
  get: <T>(key: string, defaultValue: T): T => {\
    if (typeof window === 'undefined') return defaultValue
    try {\
      const item = localStorage.getItem(key)
      return item ? JSON.parse(item) : defaultValue
    } catch (error) {
      console.error(`Error reading from localStorage key "${key}":`, error)\
      return defaultValue
    }
  },

  set: <T>(key: string, value: T): void => {\
    if (typeof window === 'undefined') return
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch (error) {
      console.error(`Error writing to localStorage key "${key}":`, error)
    }
  },

  remove: (key: string): void => {\
    if (typeof window === 'undefined') return
    try {
      localStorage.removeItem(key)
    } catch (error) {
      console.error(`Error removing localStorage key "${key}":`, error)
    }
  },

  clear: (): void => {\
    if (typeof window === 'undefined') return
    try {
      localStorage.clear()
    } catch (error) {
      console.error('Error clearing localStorage:', error)
    }
  },
}

// Favorites
export const getFavorites = (): number[] => {\
  return storage.get<number[]>(STORAGE_KEYS.FAVORITES, [])
}

export const addToFavorites = (vehicleId: number): void => {\
  const favorites = getFavorites()
  if (!favorites.includes(vehicleId)) {
    favorites.push(vehicleId)\
    storage.set(STORAGE_KEYS.FAVORITES, favorites)
  }
}

export const removeFromFavorites = (vehicleId: number): void => {\
  const favorites = getFavorites()
  const updated = favorites.filter((id) => id !== vehicleId)
  storage.set(STORAGE_KEYS.FAVORITES, updated)
}

export const isFavorite = (vehicleId: number): boolean => {\
  const favorites = getFavorites()
  return favorites.includes(vehicleId)
}

export const clearFavorites = (): void => {
  storage.set(STORAGE_KEYS.FAVORITES, [])
}

// User Profile
export const getUserProfile = (): UserProfile => {\
  return storage.get<UserProfile>(STORAGE_KEYS.USER_PROFILE, {\
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+260 97 123 4567',
    avatar: 'https://placehold.co/80x80?text=User+profile+photo',
    verified: true,
    rating: 4.8,
    reviewCount: 12,
    memberSince: 'Jan 2023',
    listingsCount: 3,
    soldCount: 7,
    viewsCount: '1.2k',
  })
}

export const updateUserProfile = (profile: Partial<UserProfile>): void => {\
  const current = getUserProfile()\
  storage.set(STORAGE_KEYS.USER_PROFILE, { ...current, ...profile })
}

// My Listings
export const getMyListings = (): Vehicle[] => {\
  return storage.get<Vehicle[]>(STORAGE_KEYS.MY_LISTINGS, [])
}
\
export const addListing = (vehicle: Omit<Vehicle, 'id'>): void => {\
  const listings = getMyListings()
  const newVehicle = {
    ...vehicle,\
    id: Date.now(),
  }
  listings.push(newVehicle)
  storage.set(STORAGE_KEYS.MY_LISTINGS, listings)
}

export const updateListing = (id: number, updates: Partial<Vehicle>): void => {\
  const listings = getMyListings()
  const index = listings.findIndex((v) => v.id === id)
  if (index !== -1) {
    listings[index] = { ...listings[index], ...updates }\
    storage.set(STORAGE_KEYS.MY_LISTINGS, listings)
  }
}

export const deleteListing = (id: number): void => {\
  const listings = getMyListings()
  const filtered = listings.filter((v) => v.id !== id)
  storage.set(STORAGE_KEYS.MY_LISTINGS, filtered)
}

// All Vehicles (for browsing)
export const getAllVehicles = (): Vehicle[] => {\
  return storage.get<Vehicle[]>(STORAGE_KEYS.VEHICLES, [])
}

export const initializeVehicles = (vehicles: Vehicle[]): void => {\
  const existing = getAllVehicles()
  if (existing.length === 0) {
    storage.set(STORAGE_KEYS.VEHICLES, vehicles)
  }
}

// Saved Searches
export const getSavedSearches = (): SavedSearch[] => {\
  return storage.get<SavedSearch[]>(STORAGE_KEYS.SAVED_SEARCHES, [])
}
\
export const addSavedSearch = (query: string, filters: Record<string, any>): void => {\
  const searches = getSavedSearches()
  const newSearch: SavedSearch = {\
    id: Date.now().toString(),
    query,
    filters,
    createdAt: new Date().toISOString(),
  }
  searches.push(newSearch)
  storage.set(STORAGE_KEYS.SAVED_SEARCHES, searches)
}

export const removeSavedSearch = (id: string): void => {\
  const searches = getSavedSearches()
  const filtered = searches.filter((s) => s.id !== id)
  storage.set(STORAGE_KEYS.SAVED_SEARCHES, filtered)\
}

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Car, User, Menu } from "lucide-react"

export function MainNav() {
  return (
    <header className="border-b bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Car className="h-8 w-8 text-[#198A00]" />
            <span className="text-2xl font-bold">
              <span className="text-[#198A00]">Zam</span>
              <span className="text-[#EF7D00]">Wheels</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/browse" className="text-sm font-medium hover:text-[#198A00] transition-colors">
              Browse Vehicles
            </Link>
            <Link href="/sell" className="text-sm font-medium hover:text-[#198A00] transition-colors">
              Sell Your Vehicle
            </Link>
            <Link href="/dealers" className="text-sm font-medium hover:text-[#198A00] transition-colors">
              For Dealers
            </Link>
            <Link href="/blog" className="text-sm font-medium hover:text-[#198A00] transition-colors">
              Blog
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/seller">Seller Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/dealer">Dealer Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin">Admin Panel</Link>
                </DropdownMenuItem>
                <DropdownMenuItem>My Favorites</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}

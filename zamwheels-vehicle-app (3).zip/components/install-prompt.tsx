"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { X, Download } from "lucide-react"

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [showPrompt, setShowPrompt] = useState(false)

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setShowPrompt(true)
    }

    window.addEventListener("beforeinstallprompt", handler)

    return () => window.removeEventListener("beforeinstallprompt", handler)
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) return

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === "accepted") {
      console.log("[v0] User accepted the install prompt")
    }

    setDeferredPrompt(null)
    setShowPrompt(false)
  }

  if (!showPrompt) return null

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 bg-zinc-900 border border-zinc-800 rounded-lg p-4 shadow-lg">
      <button onClick={() => setShowPrompt(false)} className="absolute top-2 right-2 text-zinc-400 hover:text-white">
        <X className="h-4 w-4" />
      </button>
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 bg-[#198A00] rounded-lg p-2">
          <Download className="h-5 w-5 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-white mb-1">Install ZamWheels</h3>
          <p className="text-sm text-zinc-400 mb-3">Install our app for quick access and offline browsing</p>
          <Button onClick={handleInstall} className="w-full bg-[#198A00] hover:bg-[#198A00]/90 text-white">
            Install App
          </Button>
        </div>
      </div>
    </div>
  )
}

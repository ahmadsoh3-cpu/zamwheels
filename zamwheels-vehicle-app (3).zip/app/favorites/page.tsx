"use client"

import type React from "react"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Search, Heart, Home, Package, Menu, ArrowLeft, Trash2, Filter } from "lucide-react"
import { getFavorites, removeFromFavorites, clearFavorites, getAllVehicles } from "@/lib/storage"

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    loadFavorites()

    // Listen for storage changes
    const handleStorageChange = () => {
      loadFavorites()
    }
    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  const loadFavorites = () => {
    const favoriteIds = getFavorites()
    const allVehicles = getAllVehicles()
    const favoriteVehicles = allVehicles.filter((v) => favoriteIds.includes(v.id))
    setFavorites(favoriteVehicles)
  }

  const handleRemove = (e: React.MouseEvent, vehicleId: number) => {
    e.preventDefault()
    e.stopPropagation()
    removeFromFavorites(vehicleId)
    loadFavorites()
  }

  const handleClearAll = () => {
    if (confirm("Are you sure you want to remove all favorites?")) {
      clearFavorites()
      loadFavorites()
    }
  }

  // Filter favorites based on search
  const filteredFavorites = favorites.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.details.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-zinc-950">
      {/* Mobile Header */}
      <header className="bg-zinc-900 border-b border-zinc-800 sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center gap-3 mb-3">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-zinc-800">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-lg font-bold text-white flex-1">My Favorites</h1>
            <Button variant="ghost" size="icon" className="text-white hover:bg-zinc-800">
              <Filter className="h-5 w-5" />
            </Button>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
            <Input
              placeholder="Search favorites..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-zinc-700 bg-zinc-800 text-white placeholder:text-zinc-500 h-10 text-sm"
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pb-20">
        {/* Stats Bar */}
        <div className="bg-zinc-900 px-4 py-3 border-b border-zinc-800">
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-400">{favorites.length} saved items</span>
            {favorites.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="text-[#DE2010] hover:bg-zinc-800 h-8"
                onClick={handleClearAll}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Clear All
              </Button>
            )}
          </div>
        </div>

        {/* Favorites Grid */}
        {filteredFavorites.length > 0 ? (
          <section className="px-4 py-4">
            <div className="grid grid-cols-2 gap-3">
              {filteredFavorites.map((item) => (
                <div key={item.id} className="relative">
                  <Link href={`/listing/${item.id}`}>
                    <Card className="overflow-hidden hover:shadow-md transition-shadow border border-zinc-800 bg-zinc-800">
                      <div className="relative aspect-square bg-zinc-700">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                        <Button
                          size="icon"
                          variant="ghost"
                          className="absolute top-2 right-2 h-7 w-7 rounded-full bg-black/60 hover:bg-black/80"
                          onClick={(e) => handleRemove(e, item.id)}
                        >
                          <Heart className="h-4 w-4 text-[#DE2010] fill-[#DE2010]" />
                        </Button>
                      </div>
                      <CardContent className="p-3">
                        <div className="text-base font-bold mb-1 text-white">{item.price}</div>
                        <div className="text-xs text-zinc-200 line-clamp-2 mb-1 leading-tight">{item.title}</div>
                        <div className="text-xs text-zinc-400 mb-2">{item.details}</div>
                        <div className="text-xs text-zinc-500">{item.location}</div>
                        <div className="flex items-center justify-between mt-2">
                          <div className="text-xs text-zinc-600">{item.time}</div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </div>
              ))}
            </div>
          </section>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 px-4">
            <div className="w-20 h-20 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
              <Heart className="h-10 w-10 text-zinc-600" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">No Favorites Yet</h3>
            <p className="text-zinc-400 text-center mb-6">Start adding vehicles you like to your favorites</p>
            <Link href="/">
              <Button className="bg-[#198A00] hover:bg-[#157000] text-white px-8">Browse Vehicles</Button>
            </Link>
          </div>
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-zinc-900 border-t border-zinc-800 z-50">
        <div className="flex items-center justify-around py-2">
          <Link href="/" className="flex flex-col items-center gap-1 py-2 px-4">
            <Home className="h-5 w-5 text-zinc-400" />
            <span className="text-xs text-zinc-400">Home</span>
          </Link>
          <Link href="/browse" className="flex flex-col items-center gap-1 py-2 px-4">
            <Search className="h-5 w-5 text-zinc-400" />
            <span className="text-xs text-zinc-400">Browse</span>
          </Link>
          <Link href="/sell" className="flex flex-col items-center gap-1 -mt-4 bg-[#EF7D00] rounded-full p-3 shadow-lg">
            <Package className="h-6 w-6 text-white" />
          </Link>
          <Link href="/favorites" className="flex flex-col items-center gap-1 py-2 px-4">
            <Heart className="h-5 w-5 text-[#DE2010] fill-[#DE2010]" />
            <span className="text-xs font-medium text-[#DE2010]">Favorites</span>
          </Link>
          <Link href="/account" className="flex flex-col items-center gap-1 py-2 px-4">
            <Menu className="h-5 w-5 text-zinc-400" />
            <span className="text-xs text-zinc-400">Account</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}

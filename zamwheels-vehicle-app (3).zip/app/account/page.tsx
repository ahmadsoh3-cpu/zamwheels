"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Heart,
  Home,
  Package,
  Menu,
  ChevronRight,
  User,
  Settings,
  Bell,
  HelpCircle,
  FileText,
  Shield,
  LogOut,
  Star,
  MessageSquare,
  CreditCard,
  MapPin,
  Eye,
  TrendingUp,
  Award,
} from "lucide-react"
import { getUserProfile, getFavorites, getMyListings } from "@/lib/storage"

export default function AccountPage() {
  const [profile, setProfile] = useState(getUserProfile())
  const [favoritesCount, setFavoritesCount] = useState(0)
  const [listingsCount, setListingsCount] = useState(0)

  useEffect(() => {
    setProfile(getUserProfile())
    setFavoritesCount(getFavorites().length)
    setListingsCount(getMyListings().length)

    const handleStorageChange = () => {
      setProfile(getUserProfile())
      setFavoritesCount(getFavorites().length)
      setListingsCount(getMyListings().length)
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  const userStats = [
    { label: "Listings", value: listingsCount.toString(), icon: Package },
    { label: "Sold", value: profile.soldCount.toString(), icon: TrendingUp },
    { label: "Reviews", value: profile.reviewCount.toString(), icon: Star },
    { label: "Views", value: profile.viewsCount, icon: Eye },
  ]

  const menuItems = [
    {
      title: "Account",
      items: [
        { icon: User, label: "My Profile", link: "/account/profile", badge: null },
        {
          icon: Package,
          label: "My Listings",
          link: "/dashboard/seller",
          badge: listingsCount > 0 ? listingsCount.toString() : null,
        },
        {
          icon: Heart,
          label: "Favorites",
          link: "/favorites",
          badge: favoritesCount > 0 ? favoritesCount.toString() : null,
        },
        { icon: MessageSquare, label: "Messages", link: "/account/messages", badge: "2" },
        { icon: Star, label: "Reviews & Ratings", link: "/account/reviews", badge: null },
      ],
    },
    {
      title: "Settings",
      items: [
        { icon: Bell, label: "Notifications", link: "/account/notifications", badge: null },
        { icon: MapPin, label: "Saved Addresses", link: "/account/addresses", badge: null },
        { icon: CreditCard, label: "Payment Methods", link: "/account/payments", badge: null },
        { icon: Settings, label: "Preferences", link: "/account/settings", badge: null },
      ],
    },
    {
      title: "Support",
      items: [
        { icon: HelpCircle, label: "Help Center", link: "/help", badge: null },
        { icon: FileText, label: "Terms & Conditions", link: "/terms", badge: null },
        { icon: Shield, label: "Privacy Policy", link: "/privacy", badge: null },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-zinc-950">
      {/* Mobile Header */}
      <header className="bg-zinc-900 border-b border-zinc-800 sticky top-0 z-50">
        <div className="px-4 py-3">
          <h1 className="text-lg font-bold text-white">My Account</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="pb-20">
        {/* Profile Section */}
        <section className="bg-zinc-900 px-4 py-6 border-b border-zinc-800">
          <div className="flex items-center gap-4 mb-4">
            <Avatar className="h-20 w-20 border-2 border-[#198A00]">
              <AvatarImage src={profile.avatar || "/placeholder.svg"} alt="Profile picture" />
              <AvatarFallback className="bg-zinc-800 text-white text-2xl">
                {profile.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-xl font-bold text-white">{profile.name}</h2>
                {profile.verified && <Badge className="bg-[#198A00] text-white text-xs">Verified</Badge>}
              </div>
              <p className="text-sm text-zinc-400 mb-2">{profile.email}</p>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                  <span className="text-sm font-medium text-white">{profile.rating}</span>
                </div>
                <span className="text-xs text-zinc-500">•</span>
                <span className="text-xs text-zinc-500">Member since {profile.memberSince}</span>
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-4 gap-2">
            {userStats.map((stat) => (
              <div key={stat.label} className="bg-zinc-800 rounded-lg p-3 text-center">
                <stat.icon className="h-4 w-4 text-[#198A00] mx-auto mb-1" />
                <div className="text-lg font-bold text-white">{stat.value}</div>
                <div className="text-xs text-zinc-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Upgrade to Dealer Banner */}
        <section className="px-4 py-4">
          <Card className="bg-gradient-to-r from-[#198A00] to-[#157000] border-0 overflow-hidden">
            <CardContent className="p-4 relative">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                  <Award className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-bold text-sm mb-1">Become a Dealer</h3>
                  <p className="text-white/80 text-xs">Get verified and unlock premium features</p>
                </div>
                <Button size="sm" variant="secondary" className="bg-white text-[#198A00] hover:bg-zinc-100">
                  Upgrade
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Menu Sections */}
        {menuItems.map((section) => (
          <section key={section.title} className="mb-2">
            <div className="px-4 py-2">
              <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">{section.title}</h3>
            </div>
            <div className="bg-zinc-900">
              {section.items.map((item, index) => (
                <Link key={item.label} href={item.link}>
                  <div
                    className={`flex items-center gap-3 px-4 py-4 hover:bg-zinc-800 transition-colors ${
                      index !== section.items.length - 1 ? "border-b border-zinc-800" : ""
                    }`}
                  >
                    <item.icon className="h-5 w-5 text-zinc-400" />
                    <span className="flex-1 text-white text-sm">{item.label}</span>
                    {item.badge && (
                      <Badge variant="secondary" className="bg-[#DE2010] text-white text-xs">
                        {item.badge}
                      </Badge>
                    )}
                    <ChevronRight className="h-5 w-5 text-zinc-600" />
                  </div>
                </Link>
              ))}
            </div>
          </section>
        ))}

        {/* Logout Button */}
        <section className="px-4 py-4">
          <Button
            variant="outline"
            className="w-full border-[#DE2010] text-[#DE2010] hover:bg-[#DE2010] hover:text-white bg-transparent"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </section>

        {/* App Version */}
        <div className="text-center py-4">
          <p className="text-xs text-zinc-600">ZamWheels v1.0.0</p>
        </div>
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-zinc-900 border-t border-zinc-800 z-50">
        <div className="flex items-center justify-around py-2">
          <Link href="/" className="flex flex-col items-center gap-1 py-2 px-4">
            <Home className="h-5 w-5 text-zinc-400" />
            <span className="text-xs text-zinc-400">Home</span>
          </Link>
          <Link href="/browse" className="flex flex-col items-center gap-1 py-2 px-4">
            <Search className="h-5 w-5 text-zinc-400" />
            <span className="text-xs text-zinc-400">Browse</span>
          </Link>
          <Link href="/sell" className="flex flex-col items-center gap-1 -mt-4 bg-[#EF7D00] rounded-full p-3 shadow-lg">
            <Package className="h-6 w-6 text-white" />
          </Link>
          <Link href="/favorites" className="flex flex-col items-center gap-1 py-2 px-4">
            <Heart className="h-5 w-5 text-zinc-400" />
            <span className="text-xs text-zinc-400">Favorites</span>
          </Link>
          <Link href="/account" className="flex flex-col items-center gap-1 py-2 px-4">
            <Menu className="h-5 w-5 text-[#198A00]" />
            <span className="text-xs font-medium text-[#198A00]">Account</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}

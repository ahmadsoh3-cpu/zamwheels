"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Search, Filter, Heart, MapPin, Gauge, Calendar, X, Star, CheckCircle2, Crown } from "lucide-react"
import { MainNav } from "@/components/main-nav"

// Mock data
const mockListings = [
  {
    id: 1,
    title: "2022 Toyota Hilux Double Cab",
    price: 450000,
    year: 2022,
    mileage: 35000,
    location: "Lusaka",
    images: ["https://placehold.co/400x300?text=Toyota+Hilux+silver+pickup+truck+side+view+modern+design"],
    condition: "Used",
    seller: "Verified Dealer",
    featured: true,
    urgent: false,
    rating: 4.8,
    badge: "verified",
  },
  {
    id: 2,
    title: "2020 Honda CR-V EX",
    price: 280000,
    year: 2020,
    mileage: 48000,
    location: "Kitwe",
    images: ["https://placehold.co/400x300?text=Honda+CRV+white+SUV+front+three+quarter+view"],
    condition: "Used",
    seller: "Individual",
    featured: false,
    urgent: true,
    rating: 4.5,
    badge: "verified",
  },
  {
    id: 3,
    title: "2023 Nissan Patrol Platinum",
    price: 750000,
    year: 2023,
    mileage: 12000,
    location: "Lusaka",
    images: ["https://placehold.co/400x300?text=Nissan+Patrol+black+luxury+SUV+premium+finish"],
    condition: "Used",
    seller: "Verified Dealer",
    featured: true,
    urgent: false,
    rating: 5.0,
    badge: "verified",
  },
  {
    id: 4,
    title: "2019 Toyota Fortuner",
    price: 320000,
    year: 2019,
    mileage: 65000,
    location: "Ndola",
    images: ["https://placehold.co/400x300?text=Toyota+Fortuner+gray+SUV+rugged+outdoor+setting"],
    condition: "Used",
    seller: "Individual",
    featured: false,
    urgent: false,
    rating: 4.3,
    badge: "verified",
  },
  {
    id: 5,
    title: "2021 Mazda CX-5 Touring",
    price: 245000,
    year: 2021,
    mileage: 42000,
    location: "Lusaka",
    images: ["https://placehold.co/400x300?text=Mazda+CX5+red+crossover+dynamic+angle"],
    condition: "Used",
    seller: "Verified Dealer",
    featured: true,
    urgent: false,
    rating: 4.7,
    badge: "verified",
  },
  {
    id: 6,
    title: "2018 Ford Ranger Wildtrak",
    price: 380000,
    year: 2018,
    mileage: 78000,
    location: "Livingstone",
    images: ["https://placehold.co/400x300?text=Ford+Ranger+blue+offroad+pickup+truck"],
    condition: "Used",
    seller: "Individual",
    featured: false,
    urgent: true,
    rating: 4.4,
    badge: "verified",
  },
]

export default function BrowsePage() {
  const [showFilters, setShowFilters] = useState(false)
  const [priceRange, setPriceRange] = useState([0, 1000000])
  const [favorites, setFavorites] = useState<number[]>([])

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => (prev.includes(id) ? prev.filter((fId) => fId !== id) : [...prev, id]))
  }

  const featuredListings = mockListings.filter((l) => l.featured)
  const regularListings = mockListings.filter((l) => !l.featured)

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />

      <div className="container mx-auto px-4 py-6">
        {/* Search Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 flex items-center gap-2 border rounded-lg px-4">
              <Search className="h-5 w-5 text-muted-foreground" />
              <Input placeholder="Search by make, model, or keyword..." className="border-0 focus-visible:ring-0" />
            </div>

            <div className="flex gap-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="cars">Cars</SelectItem>
                  <SelectItem value="motorcycles">Motorcycles</SelectItem>
                  <SelectItem value="trucks">Trucks</SelectItem>
                  <SelectItem value="vans">Vans</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="gap-2">
                <Filter className="h-4 w-4" />
                Filters
              </Button>

              <Button className="bg-[#198A00] hover:bg-[#157000]">Search</Button>
            </div>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Filters Sidebar */}
          {showFilters && (
            <aside className="w-80 flex-shrink-0">
              <Card>
                <CardContent className="p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-lg">Filters</h3>
                    <Button variant="ghost" size="sm" onClick={() => setShowFilters(false)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Condition</label>
                    <Select defaultValue="all">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Conditions</SelectItem>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="used">Used</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Make</label>
                    <Select defaultValue="all">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Makes</SelectItem>
                        <SelectItem value="toyota">Toyota</SelectItem>
                        <SelectItem value="honda">Honda</SelectItem>
                        <SelectItem value="nissan">Nissan</SelectItem>
                        <SelectItem value="mazda">Mazda</SelectItem>
                        <SelectItem value="ford">Ford</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Year Range</label>
                    <div className="flex gap-2">
                      <Select defaultValue="2015">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 10 }, (_, i) => 2024 - i).map((year) => (
                            <SelectItem key={year} value={year.toString()}>
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <span className="self-center">to</span>
                      <Select defaultValue="2024">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 10 }, (_, i) => 2024 - i).map((year) => (
                            <SelectItem key={year} value={year.toString()}>
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-3 block">
                      Price Range: ZMW {priceRange[0].toLocaleString()} - {priceRange[1].toLocaleString()}
                    </label>
                    <Slider
                      min={0}
                      max={1000000}
                      step={10000}
                      value={priceRange}
                      onValueChange={setPriceRange}
                      className="mb-2"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Location</label>
                    <Select defaultValue="all">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Locations</SelectItem>
                        <SelectItem value="lusaka">Lusaka</SelectItem>
                        <SelectItem value="kitwe">Kitwe</SelectItem>
                        <SelectItem value="ndola">Ndola</SelectItem>
                        <SelectItem value="livingstone">Livingstone</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Seller Type</label>
                    <Select defaultValue="all">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Sellers</SelectItem>
                        <SelectItem value="dealer">Verified Dealers</SelectItem>
                        <SelectItem value="individual">Individuals</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button className="w-full bg-[#198A00] hover:bg-[#157000]">Apply Filters</Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    Clear All
                  </Button>
                </CardContent>
              </Card>
            </aside>
          )}

          {/* Listings */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold">Browse Vehicles</h2>
                <p className="text-muted-foreground">Showing {mockListings.length} results</p>
              </div>

              <Select defaultValue="newest">
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="mileage">Lowest Mileage</SelectItem>
                  <SelectItem value="year">Newest Year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Featured Listings */}
            {featuredListings.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Crown className="h-5 w-5 text-[#EF7D00]" />
                  <h3 className="text-lg font-semibold">Featured Listings</h3>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {featuredListings.map((listing) => (
                    <Card
                      key={listing.id}
                      className="overflow-hidden hover:shadow-lg transition-shadow border-2 border-[#EF7D00]/20"
                    >
                      <div className="relative">
                        <img
                          src={listing.images[0] || "/placeholder.svg"}
                          alt={listing.title}
                          className="w-full h-48 object-cover"
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="absolute top-2 right-2 bg-white/90 hover:bg-white"
                          onClick={() => toggleFavorite(listing.id)}
                        >
                          <Heart
                            className={`h-5 w-5 ${favorites.includes(listing.id) ? "fill-[#DE2010] text-[#DE2010]" : ""}`}
                          />
                        </Button>
                        <Badge className="absolute top-2 left-2 bg-[#EF7D00]">
                          <Crown className="h-3 w-3 mr-1" />
                          Featured
                        </Badge>
                        {listing.urgent && <Badge className="absolute top-11 left-2 bg-[#DE2010]">Urgent</Badge>}
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-lg line-clamp-1">{listing.title}</h3>
                          {listing.badge === "verified" && (
                            <CheckCircle2 className="h-5 w-5 text-[#198A00] flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-2xl font-bold text-[#198A00] mb-3">ZMW {listing.price.toLocaleString()}</p>
                        <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground mb-3">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {listing.year}
                          </div>
                          <div className="flex items-center gap-1">
                            <Gauge className="h-4 w-4" />
                            {listing.mileage.toLocaleString()} km
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {listing.location}
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-[#EF7D00] text-[#EF7D00]" />
                            {listing.rating}
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">{listing.seller}</span>
                          <Button size="sm" className="bg-[#198A00] hover:bg-[#157000]" asChild>
                            <Link href={`/listing/${listing.id}`}>View Details</Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Regular Listings */}
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-4">All Listings</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {regularListings.map((listing) => (
                  <Card key={listing.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <img
                        src={listing.images[0] || "/placeholder.svg"}
                        alt={listing.title}
                        className="w-full h-48 object-cover"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2 bg-white/90 hover:bg-white"
                        onClick={() => toggleFavorite(listing.id)}
                      >
                        <Heart
                          className={`h-5 w-5 ${favorites.includes(listing.id) ? "fill-[#DE2010] text-[#DE2010]" : ""}`}
                        />
                      </Button>
                      {listing.urgent && <Badge className="absolute top-2 left-2 bg-[#DE2010]">Urgent</Badge>}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-lg line-clamp-1">{listing.title}</h3>
                        {listing.badge === "verified" && (
                          <CheckCircle2 className="h-5 w-5 text-[#198A00] flex-shrink-0" />
                        )}
                      </div>
                      <p className="text-2xl font-bold text-[#198A00] mb-3">ZMW {listing.price.toLocaleString()}</p>
                      <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground mb-3">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {listing.year}
                        </div>
                        <div className="flex items-center gap-1">
                          <Gauge className="h-4 w-4" />
                          {listing.mileage.toLocaleString()} km
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {listing.location}
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-[#EF7D00] text-[#EF7D00]" />
                          {listing.rating}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">{listing.seller}</span>
                        <Button size="sm" className="bg-[#198A00] hover:bg-[#157000]" asChild>
                          <Link href={`/listing/${listing.id}`}>View Details</Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Users,
  Car,
  DollarSign,
  TrendingUp,
  CheckCircle2,
  XCircle,
  Clock,
  MoreVertical,
  Shield,
  Flag,
  Eye,
  Search,
} from "lucide-react"
import { MainNav } from "@/components/main-nav"

const mockPendingListings = [
  {
    id: 1,
    title: "2022 Toyota Hilux Double Cab",
    seller: "John Doe",
    sellerType: "Individual",
    price: 450000,
    submittedAt: "2024-01-20 10:30",
    image: "https://placehold.co/100x75?text=Toyota+Hilux",
  },
  {
    id: 2,
    title: "2019 Honda Fit Hybrid",
    seller: "Premium Motors",
    sellerType: "Dealer",
    price: 120000,
    submittedAt: "2024-01-20 14:15",
    image: "https://placehold.co/100x75?text=Honda+Fit",
  },
]

const mockUsers = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    type: "Individual",
    verified: true,
    listings: 3,
    joinedAt: "2023-12-01",
  },
  {
    id: 2,
    name: "Premium Motors",
    email: "sales@premium.com",
    type: "Dealer",
    verified: true,
    listings: 45,
    joinedAt: "2023-01-15",
  },
]

const mockFlaggedListings = [
  {
    id: 1,
    title: "Suspicious Pricing - 2020 BMW X5",
    reason: "Price significantly below market value",
    reportedBy: "Multiple users",
    status: "pending",
  },
]

export default function AdminDashboard() {
  const [searchQuery, setSearchQuery] = useState("")

  const stats = {
    totalUsers: 150234,
    activeListings: 20456,
    pendingApprovals: 45,
    monthlyRevenue: 1240000,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Platform management and moderation</p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Total Users</p>
                <Users className="h-5 w-5 text-[#198A00]" />
              </div>
              <p className="text-3xl font-bold mb-1">{stats.totalUsers.toLocaleString()}</p>
              <p className="text-sm text-[#198A00] flex items-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +2,340 this month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Active Listings</p>
                <Car className="h-5 w-5 text-[#198A00]" />
              </div>
              <p className="text-3xl font-bold mb-1">{stats.activeListings.toLocaleString()}</p>
              <p className="text-sm text-[#198A00] flex items-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +456 this week
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Pending Approvals</p>
                <Clock className="h-5 w-5 text-[#EF7D00]" />
              </div>
              <p className="text-3xl font-bold mb-1">{stats.pendingApprovals}</p>
              <p className="text-sm text-muted-foreground">Requires review</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                <DollarSign className="h-5 w-5 text-[#EF7D00]" />
              </div>
              <p className="text-3xl font-bold mb-1">1.24M</p>
              <p className="text-sm text-[#198A00] flex items-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +18% vs last month
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Card>
          <CardContent className="p-6">
            <Tabs defaultValue="listings">
              <TabsList>
                <TabsTrigger value="listings">
                  Pending Listings
                  <Badge className="ml-2 bg-[#EF7D00]">{mockPendingListings.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="users">Users</TabsTrigger>
                <TabsTrigger value="flagged">
                  Flagged Content
                  <Badge className="ml-2 bg-[#DE2010]">{mockFlaggedListings.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              {/* Pending Listings */}
              <TabsContent value="listings" className="space-y-4 mt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex-1 flex items-center gap-2 border rounded-lg px-4">
                    <Search className="h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search listings..."
                      className="border-0 focus-visible:ring-0"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="individual">Individual</SelectItem>
                      <SelectItem value="dealer">Dealer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {mockPendingListings.map((listing) => (
                  <Card key={listing.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <img
                          src={listing.image || "/placeholder.svg"}
                          alt={listing.title}
                          className="w-24 h-18 object-cover rounded"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold mb-1">{listing.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2">
                            Seller: {listing.seller} ({listing.sellerType})
                          </p>
                          <div className="flex items-center gap-4 text-sm">
                            <span className="font-bold text-[#198A00]">ZMW {listing.price.toLocaleString()}</span>
                            <span className="text-muted-foreground">Submitted: {listing.submittedAt}</span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4 mr-2" />
                            Review
                          </Button>
                          <Button size="sm" className="bg-[#198A00] hover:bg-[#157000]">
                            <CheckCircle2 className="h-4 w-4 mr-2" />
                            Approve
                          </Button>
                          <Button size="sm" variant="destructive">
                            <XCircle className="h-4 w-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Users */}
              <TabsContent value="users" className="space-y-4 mt-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex-1 flex items-center gap-2 border rounded-lg px-4">
                    <Search className="h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Search users..." className="border-0 focus-visible:ring-0" />
                  </div>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="individual">Individuals</SelectItem>
                      <SelectItem value="dealer">Dealers</SelectItem>
                      <SelectItem value="verified">Verified Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  {mockUsers.map((user) => (
                    <Card key={user.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="h-12 w-12 rounded-full bg-[#198A00] text-white flex items-center justify-center font-bold">
                              {user.name.charAt(0)}
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="font-semibold">{user.name}</h3>
                                {user.verified && <CheckCircle2 className="h-4 w-4 text-[#198A00]" />}
                                <Badge variant="secondary">{user.type}</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">{user.email}</p>
                              <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                                <span>{user.listings} listings</span>
                                <span>Joined: {new Date(user.joinedAt).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                View Profile
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Shield className="h-4 w-4 mr-2" />
                                Toggle Verification
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive">
                                <XCircle className="h-4 w-4 mr-2" />
                                Suspend Account
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Flagged Content */}
              <TabsContent value="flagged" className="space-y-4 mt-6">
                {mockFlaggedListings.map((item) => (
                  <Card key={item.id} className="border-[#DE2010]/30">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <Flag className="h-5 w-5 text-[#DE2010] flex-shrink-0 mt-1" />
                        <div className="flex-1">
                          <h3 className="font-semibold mb-1">{item.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2">Reason: {item.reason}</p>
                          <p className="text-sm text-muted-foreground">Reported by: {item.reportedBy}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4 mr-2" />
                            Review
                          </Button>
                          <Button size="sm" variant="destructive">
                            <XCircle className="h-4 w-4 mr-2" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Analytics */}
              <TabsContent value="analytics" className="mt-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Platform Growth</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between mb-2">
                            <span className="text-sm">New Users</span>
                            <span className="font-bold">+2,340</span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-[#198A00]" style={{ width: "85%" }} />
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between mb-2">
                            <span className="text-sm">New Listings</span>
                            <span className="font-bold">+456</span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-[#EF7D00]" style={{ width: "72%" }} />
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between mb-2">
                            <span className="text-sm">Transactions</span>
                            <span className="font-bold">+123</span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-[#198A00]" style={{ width: "68%" }} />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Revenue Sources</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {[
                          { label: "Featured Listings", amount: 620000, percentage: 50 },
                          { label: "Boost to Top", amount: 372000, percentage: 30 },
                          { label: "Dealer Packages", amount: 248000, percentage: 20 },
                        ].map((item, i) => (
                          <div key={i}>
                            <div className="flex justify-between mb-2">
                              <span className="text-sm">{item.label}</span>
                              <span className="font-bold">ZMW {item.amount.toLocaleString()}</span>
                            </div>
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div className="h-full bg-[#198A00]" style={{ width: `${item.percentage}%` }} />
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

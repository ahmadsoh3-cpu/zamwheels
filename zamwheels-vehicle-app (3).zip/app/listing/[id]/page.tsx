"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Heart,
  Share2,
  MapPin,
  Calendar,
  Gauge,
  Fuel,
  Cog,
  Palette,
  Car,
  CheckCircle2,
  Star,
  Phone,
  MessageCircle,
  AlertCircle,
  Shield,
  FileText,
  ChevronLeft,
  ChevronRight,
  Crown,
} from "lucide-react"
import { MainNav } from "@/components/main-nav"

export default function ListingDetailPage() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isFavorite, setIsFavorite] = useState(false)

  const listing = {
    id: 1,
    title: "2022 Toyota Hilux Double Cab",
    price: 450000,
    year: 2022,
    make: "Toyota",
    model: "Hilux",
    variant: "Double Cab 2.8 GD-6 4x4",
    mileage: 35000,
    location: "Lusaka, Zambia",
    condition: "Used",
    bodyType: "Pickup Truck",
    fuelType: "Diesel",
    transmission: "Automatic",
    engineSize: "2.8L",
    color: "Silver",
    doors: 4,
    seats: 5,
    featured: true,
    urgent: false,
    images: [
      "https://placehold.co/800x600?text=Toyota+Hilux+silver+pickup+truck+front+three+quarter+view",
      "https://placehold.co/800x600?text=Toyota+Hilux+interior+dashboard+steering+wheel+modern+cabin",
      "https://placehold.co/800x600?text=Toyota+Hilux+rear+view+truck+bed+silver+finish",
      "https://placehold.co/800x600?text=Toyota+Hilux+side+profile+wheels+and+design+details",
    ],
    description:
      "Pristine 2022 Toyota Hilux Double Cab in excellent condition. This powerful and reliable pickup truck has been meticulously maintained with full service history. Perfect for both business and leisure use. Features include air conditioning, power steering, electric windows, central locking, and much more. Single owner, accident-free. All documentation available. Serious buyers only.",
    features: [
      "Air Conditioning",
      "Power Steering",
      "Electric Windows",
      "Central Locking",
      "ABS Brakes",
      "Airbags",
      "Cruise Control",
      "Bluetooth",
      "Reverse Camera",
      "Alloy Wheels",
      "Fog Lights",
      "Roof Rack",
    ],
    seller: {
      name: "Premium Motors Zambia",
      type: "Verified Dealer",
      rating: 4.8,
      reviews: 156,
      verified: true,
      memberSince: "2019",
      responseTime: "Within 1 hour",
      phone: "+260 97 123 4567",
      email: "sales@premiummotors.zm",
    },
    inspection: {
      available: true,
      rating: "Excellent",
      date: "December 2024",
      notes: "Professional inspection completed. Vehicle in excellent mechanical and cosmetic condition.",
    },
    history: {
      owners: 1,
      accidents: 0,
      serviceRecords: "Full service history available",
    },
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % listing.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + listing.images.length) % listing.images.length)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />

      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link href="/" className="hover:text-foreground">
            Home
          </Link>
          <span>/</span>
          <Link href="/browse" className="hover:text-foreground">
            Browse
          </Link>
          <span>/</span>
          <Link href="/browse?category=cars" className="hover:text-foreground">
            Cars
          </Link>
          <span>/</span>
          <span className="text-foreground">{listing.title}</span>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <Card className="overflow-hidden">
              <div className="relative">
                <img
                  src={listing.images[currentImageIndex] || "/placeholder.svg"}
                  alt={`${listing.title} - Image ${currentImageIndex + 1}`}
                  className="w-full h-[500px] object-cover"
                />

                {/* Navigation Buttons */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={prevImage}
                >
                  <ChevronLeft className="h-6 w-6" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white"
                  onClick={nextImage}
                >
                  <ChevronRight className="h-6 w-6" />
                </Button>

                {/* Action Buttons */}
                <div className="absolute top-4 right-4 flex gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="bg-white/90 hover:bg-white"
                    onClick={() => setIsFavorite(!isFavorite)}
                  >
                    <Heart className={`h-5 w-5 ${isFavorite ? "fill-[#DE2010] text-[#DE2010]" : ""}`} />
                  </Button>
                  <Button variant="ghost" size="icon" className="bg-white/90 hover:bg-white">
                    <Share2 className="h-5 w-5" />
                  </Button>
                </div>

                {/* Badges */}
                {listing.featured && (
                  <Badge className="absolute top-4 left-4 bg-[#EF7D00]">
                    <Crown className="h-3 w-3 mr-1" />
                    Featured
                  </Badge>
                )}

                {/* Image Counter */}
                <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-lg text-sm">
                  {currentImageIndex + 1} / {listing.images.length}
                </div>
              </div>

              {/* Thumbnail Strip */}
              <div className="p-4 flex gap-2 overflow-x-auto">
                {listing.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                      currentImageIndex === index ? "border-[#198A00]" : "border-transparent"
                    }`}
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </Card>

            {/* Vehicle Details Tabs */}
            <Card>
              <CardContent className="p-6">
                <Tabs defaultValue="details">
                  <TabsList className="w-full justify-start">
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="features">Features</TabsTrigger>
                    <TabsTrigger value="inspection">Inspection</TabsTrigger>
                    <TabsTrigger value="history">History</TabsTrigger>
                  </TabsList>

                  <TabsContent value="details" className="space-y-4 mt-6">
                    <div>
                      <h3 className="font-semibold text-lg mb-4">Description</h3>
                      <p className="text-muted-foreground leading-relaxed">{listing.description}</p>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="font-semibold text-lg mb-4">Specifications</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="flex items-center gap-3">
                          <Car className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Make & Model</p>
                            <p className="font-medium">
                              {listing.make} {listing.model}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Calendar className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Year</p>
                            <p className="font-medium">{listing.year}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Gauge className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Mileage</p>
                            <p className="font-medium">{listing.mileage.toLocaleString()} km</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Fuel className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Fuel Type</p>
                            <p className="font-medium">{listing.fuelType}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Cog className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Transmission</p>
                            <p className="font-medium">{listing.transmission}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Cog className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Engine Size</p>
                            <p className="font-medium">{listing.engineSize}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Palette className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Color</p>
                            <p className="font-medium">{listing.color}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <MapPin className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="text-sm text-muted-foreground">Location</p>
                            <p className="font-medium">{listing.location}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="features" className="mt-6">
                    <h3 className="font-semibold text-lg mb-4">Features & Extras</h3>
                    <div className="grid md:grid-cols-2 gap-3">
                      {listing.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2">
                          <CheckCircle2 className="h-5 w-5 text-[#198A00]" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="inspection" className="mt-6">
                    <div className="space-y-4">
                      <div className="flex items-start gap-4 p-4 bg-[#198A00]/5 rounded-lg">
                        <Shield className="h-6 w-6 text-[#198A00] flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-2">Professional Inspection Available</h3>
                          <p className="text-sm text-muted-foreground mb-3">{listing.inspection.notes}</p>
                          <div className="grid md:grid-cols-2 gap-3 text-sm">
                            <div>
                              <span className="text-muted-foreground">Rating:</span>
                              <span className="font-medium ml-2">{listing.inspection.rating}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Inspection Date:</span>
                              <span className="font-medium ml-2">{listing.inspection.date}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Button className="w-full bg-transparent" variant="outline">
                        <FileText className="h-4 w-4 mr-2" />
                        View Full Inspection Report
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="history" className="mt-6">
                    <div className="space-y-4">
                      <div className="grid md:grid-cols-3 gap-4">
                        <Card>
                          <CardContent className="p-4 text-center">
                            <div className="text-3xl font-bold text-[#198A00] mb-1">{listing.history.owners}</div>
                            <p className="text-sm text-muted-foreground">Previous Owner</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4 text-center">
                            <div className="text-3xl font-bold text-[#198A00] mb-1">{listing.history.accidents}</div>
                            <p className="text-sm text-muted-foreground">Accidents Reported</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4 text-center">
                            <CheckCircle2 className="h-10 w-10 text-[#198A00] mx-auto mb-1" />
                            <p className="text-sm text-muted-foreground">Full Service History</p>
                          </CardContent>
                        </Card>
                      </div>
                      <p className="text-sm text-muted-foreground">{listing.history.serviceRecords}</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Price Card */}
            <Card>
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-[#198A00] mb-4">ZMW {listing.price.toLocaleString()}</div>

                <div className="space-y-3 mb-6">
                  <Button className="w-full bg-[#198A00] hover:bg-[#157000]" size="lg">
                    <Phone className="h-4 w-4 mr-2" />
                    Call Seller
                  </Button>
                  <Button className="w-full bg-transparent" variant="outline" size="lg">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Send Message
                  </Button>
                  <Button className="w-full bg-[#EF7D00] hover:bg-[#d67000]" size="lg">
                    Make an Offer
                  </Button>
                </div>

                <Separator className="my-4" />

                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Condition</span>
                    <Badge variant="secondary">{listing.condition}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Body Type</span>
                    <span className="font-medium">{listing.bodyType}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Seller Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Seller Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-[#198A00] text-white">PM</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{listing.seller.name}</h3>
                      {listing.seller.verified && <CheckCircle2 className="h-4 w-4 text-[#198A00]" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{listing.seller.type}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 fill-[#EF7D00] text-[#EF7D00]" />
                  <span className="font-medium">{listing.seller.rating}</span>
                  <span className="text-sm text-muted-foreground">({listing.seller.reviews} reviews)</span>
                </div>

                <Separator />

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Member Since</span>
                    <span className="font-medium">{listing.seller.memberSince}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Response Time</span>
                    <span className="font-medium">{listing.seller.responseTime}</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href={`/seller/${listing.seller.name}`}>View All Listings</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Safety Tips */}
            <Card className="border-[#EF7D00]/30 bg-[#EF7D00]/5">
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-[#EF7D00] flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold mb-2">Safety Tips</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Meet in a safe public location</li>
                      <li>• Inspect the vehicle thoroughly</li>
                      <li>• Verify all documents</li>
                      <li>• Never pay before seeing the vehicle</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

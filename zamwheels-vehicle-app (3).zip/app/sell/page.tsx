"use client"

import { Badge } from "@/components/ui/badge"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { X, Plus, AlertCircle, CheckCircle2, TrendingUp } from "lucide-react"
import { MainNav } from "@/components/main-nav"

export default function SellPage() {
  const [step, setStep] = useState(1)
  const [uploadedImages, setUploadedImages] = useState<string[]>([])
  const [estimatedPrice, setEstimatedPrice] = useState(0)

  const addImage = () => {
    // Simulate image upload
    const newImage = `https://placehold.co/200x150?text=Vehicle+Photo+${uploadedImages.length + 1}`
    setUploadedImages([...uploadedImages, newImage])
  }

  const removeImage = (index: number) => {
    setUploadedImages(uploadedImages.filter((_, i) => i !== index))
  }

  const calculateEstimate = () => {
    // Simulate price estimation
    setEstimatedPrice(Math.floor(Math.random() * 500000) + 100000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-3">Sell Your Vehicle</h1>
            <p className="text-muted-foreground text-lg">
              Create your listing in minutes and reach thousands of buyers
            </p>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-center gap-2 mb-8">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center">
                <div
                  className={`h-10 w-10 rounded-full flex items-center justify-center font-semibold ${
                    step >= s ? "bg-[#198A00] text-white" : "bg-gray-200 text-gray-500"
                  }`}
                >
                  {s}
                </div>
                {s < 4 && <div className={`h-1 w-12 ${step > s ? "bg-[#198A00]" : "bg-gray-200"}`} />}
              </div>
            ))}
          </div>

          {/* Step 1: Basic Information */}
          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Vehicle Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Category *</Label>
                    <Select>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cars">Cars</SelectItem>
                        <SelectItem value="motorcycles">Motorcycles</SelectItem>
                        <SelectItem value="trucks">Trucks</SelectItem>
                        <SelectItem value="vans">Vans</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="condition">Condition *</Label>
                    <Select>
                      <SelectTrigger id="condition">
                        <SelectValue placeholder="Select condition" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="used">Used</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="make">Make *</Label>
                    <Select>
                      <SelectTrigger id="make">
                        <SelectValue placeholder="Select make" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="toyota">Toyota</SelectItem>
                        <SelectItem value="honda">Honda</SelectItem>
                        <SelectItem value="nissan">Nissan</SelectItem>
                        <SelectItem value="mazda">Mazda</SelectItem>
                        <SelectItem value="ford">Ford</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="model">Model *</Label>
                    <Input id="model" placeholder="e.g., Hilux" />
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="year">Year *</Label>
                    <Select>
                      <SelectTrigger id="year">
                        <SelectValue placeholder="Year" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 15 }, (_, i) => 2024 - i).map((year) => (
                          <SelectItem key={year} value={year.toString()}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="mileage">Mileage (km) *</Label>
                    <Input id="mileage" type="number" placeholder="e.g., 35000" />
                  </div>

                  <div>
                    <Label htmlFor="price">Price (ZMW) *</Label>
                    <Input id="price" type="number" placeholder="e.g., 450000" />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fuelType">Fuel Type *</Label>
                    <Select>
                      <SelectTrigger id="fuelType">
                        <SelectValue placeholder="Select fuel type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="petrol">Petrol</SelectItem>
                        <SelectItem value="diesel">Diesel</SelectItem>
                        <SelectItem value="hybrid">Hybrid</SelectItem>
                        <SelectItem value="electric">Electric</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="transmission">Transmission *</Label>
                    <Select>
                      <SelectTrigger id="transmission">
                        <SelectValue placeholder="Select transmission" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="automatic">Automatic</SelectItem>
                        <SelectItem value="manual">Manual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="location">Location *</Label>
                  <Select>
                    <SelectTrigger id="location">
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lusaka">Lusaka</SelectItem>
                      <SelectItem value="kitwe">Kitwe</SelectItem>
                      <SelectItem value="ndola">Ndola</SelectItem>
                      <SelectItem value="livingstone">Livingstone</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Price Estimator */}
                <Card className="bg-[#198A00]/5 border-[#198A00]/20">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold mb-1 flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-[#198A00]" />
                          Price Estimator
                        </h4>
                        <p className="text-sm text-muted-foreground mb-3">
                          Get an estimated market value for your vehicle
                        </p>
                        {estimatedPrice > 0 && (
                          <div className="text-2xl font-bold text-[#198A00]">ZMW {estimatedPrice.toLocaleString()}</div>
                        )}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={calculateEstimate}
                        className="border-[#198A00] text-[#198A00] bg-transparent"
                      >
                        Calculate
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-end">
                  <Button className="bg-[#198A00] hover:bg-[#157000]" onClick={() => setStep(2)}>
                    Continue
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Photos & Media */}
          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle>Photos & Media</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Vehicle Photos * (Minimum 4 photos required)</Label>
                  <p className="text-sm text-muted-foreground">
                    Upload high-quality images from different angles. First image will be the cover photo.
                  </p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {uploadedImages.map((image, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`Upload ${index + 1}`}
                        className="w-full h-32 object-cover rounded-lg border"
                      />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeImage(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                      {index === 0 && (
                        <div className="absolute bottom-2 left-2 bg-[#198A00] text-white text-xs px-2 py-1 rounded">
                          Cover
                        </div>
                      )}
                    </div>
                  ))}

                  {uploadedImages.length < 10 && (
                    <button
                      onClick={addImage}
                      className="h-32 border-2 border-dashed rounded-lg flex flex-col items-center justify-center hover:border-[#198A00] hover:bg-[#198A00]/5 transition-colors"
                    >
                      <Plus className="h-8 w-8 text-muted-foreground mb-1" />
                      <span className="text-sm text-muted-foreground">Add Photo</span>
                    </button>
                  )}
                </div>

                <div>
                  <Label htmlFor="videoUrl">Video URL (Optional)</Label>
                  <Input id="videoUrl" placeholder="e.g., https://youtube.com/watch?v=..." />
                  <p className="text-sm text-muted-foreground mt-1">
                    Add a YouTube or other video link for a virtual tour
                  </p>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep(1)}>
                    Back
                  </Button>
                  <Button
                    className="bg-[#198A00] hover:bg-[#157000]"
                    onClick={() => setStep(3)}
                    disabled={uploadedImages.length < 4}
                  >
                    Continue
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Description & Features */}
          {step === 3 && (
            <Card>
              <CardHeader>
                <CardTitle>Description & Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Listing Title *</Label>
                  <Input id="title" placeholder="e.g., 2022 Toyota Hilux Double Cab" maxLength={100} />
                </div>

                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your vehicle's condition, history, and any special features..."
                    rows={6}
                    maxLength={2000}
                  />
                  <p className="text-sm text-muted-foreground mt-1">Be detailed and honest to attract serious buyers</p>
                </div>

                <div>
                  <Label className="mb-3 block">Features & Extras</Label>
                  <div className="grid md:grid-cols-2 gap-3">
                    {[
                      "Air Conditioning",
                      "Power Steering",
                      "Electric Windows",
                      "Central Locking",
                      "ABS Brakes",
                      "Airbags",
                      "Cruise Control",
                      "Bluetooth",
                      "Reverse Camera",
                      "Alloy Wheels",
                      "Fog Lights",
                      "Sunroof",
                    ].map((feature) => (
                      <div key={feature} className="flex items-center gap-2">
                        <Checkbox id={feature} />
                        <Label htmlFor={feature} className="font-normal cursor-pointer">
                          {feature}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep(2)}>
                    Back
                  </Button>
                  <Button className="bg-[#198A00] hover:bg-[#157000]" onClick={() => setStep(4)}>
                    Continue
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 4: Review & Publish */}
          {step === 4 && (
            <Card>
              <CardHeader>
                <CardTitle>Review & Publish</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <h3 className="font-semibold">Contact Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input id="phone" placeholder="+260 97 123 4567" />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input id="email" type="email" placeholder="your@email.com" />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold">Promotion Options (Optional)</h3>
                  <div className="space-y-3">
                    <Card className="border-[#EF7D00]/30">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Checkbox id="featured" />
                              <Label htmlFor="featured" className="font-semibold cursor-pointer">
                                Featured Listing
                              </Label>
                              <Badge className="bg-[#EF7D00]">Popular</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground ml-6">
                              Stay at the top of search results for 30 days
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-lg">ZMW 500</div>
                            <div className="text-sm text-muted-foreground">30 days</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-[#EF7D00]/30">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Checkbox id="boost" />
                              <Label htmlFor="boost" className="font-semibold cursor-pointer">
                                Boost to Top
                              </Label>
                            </div>
                            <p className="text-sm text-muted-foreground ml-6">Instantly push your listing to the top</p>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-lg">ZMW 100</div>
                            <div className="text-sm text-muted-foreground">One-time</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-[#DE2010]/30">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Checkbox id="urgent" />
                              <Label htmlFor="urgent" className="font-semibold cursor-pointer">
                                Urgent Tag
                              </Label>
                            </div>
                            <p className="text-sm text-muted-foreground ml-6">
                              Add an "Urgent" badge to attract quick buyers
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-lg">ZMW 50</div>
                            <div className="text-sm text-muted-foreground">7 days</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-semibold mb-1">Before Publishing</p>
                        <ul className="space-y-1 text-muted-foreground">
                          <li>• Double-check all vehicle details are accurate</li>
                          <li>• Ensure photos are clear and high-quality</li>
                          <li>• Set a competitive price based on market value</li>
                          <li>• Your listing will be reviewed within 24 hours</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep(3)}>
                    Back
                  </Button>
                  <Button className="bg-[#198A00] hover:bg-[#157000]" size="lg">
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Publish Listing
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

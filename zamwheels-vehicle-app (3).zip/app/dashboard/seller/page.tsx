"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Car,
  Plus,
  Eye,
  MessageCircle,
  Heart,
  Edit,
  Trash2,
  MoreVertical,
  RefreshCw,
  Crown,
  CheckCircle2,
  Clock,
  XCircle,
} from "lucide-react"
import { MainNav } from "@/components/main-nav"

const mockListings = [
  {
    id: 1,
    title: "2022 Toyota Hilux Double Cab",
    price: 450000,
    status: "active",
    views: 1234,
    inquiries: 45,
    favorites: 23,
    image: "https://placehold.co/200x150?text=Toyota+Hilux+silver+pickup",
    createdAt: "2024-01-15",
    featured: true,
  },
  {
    id: 2,
    title: "2019 Honda Fit Hybrid",
    price: 120000,
    status: "pending",
    views: 234,
    inquiries: 12,
    favorites: 8,
    image: "https://placehold.co/200x150?text=Honda+Fit+blue+hatchback",
    createdAt: "2024-01-20",
    featured: false,
  },
  {
    id: 3,
    title: "2020 Mazda CX-5 Touring",
    price: 245000,
    status: "sold",
    views: 2156,
    inquiries: 89,
    favorites: 45,
    image: "https://placehold.co/200x150?text=Mazda+CX5+red+SUV",
    createdAt: "2023-12-10",
    featured: false,
  },
]

export default function SellerDashboard() {
  const [activeTab, setActiveTab] = useState("active")

  const stats = {
    totalListings: mockListings.length,
    activeListings: mockListings.filter((l) => l.status === "active").length,
    totalViews: mockListings.reduce((sum, l) => sum + l.views, 0),
    totalInquiries: mockListings.reduce((sum, l) => sum + l.inquiries, 0),
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge className="bg-[#198A00]">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Active
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary">
            <Clock className="h-3 w-3 mr-1" />
            Pending Review
          </Badge>
        )
      case "sold":
        return (
          <Badge variant="outline">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Sold
          </Badge>
        )
      case "expired":
        return (
          <Badge variant="destructive">
            <XCircle className="h-3 w-3 mr-1" />
            Expired
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Seller Dashboard</h1>
            <p className="text-muted-foreground">Manage your vehicle listings and track performance</p>
          </div>
          <Button className="bg-[#198A00] hover:bg-[#157000]" asChild>
            <Link href="/sell">
              <Plus className="h-4 w-4 mr-2" />
              Create New Listing
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Listings</p>
                  <p className="text-3xl font-bold">{stats.totalListings}</p>
                </div>
                <Car className="h-10 w-10 text-[#198A00] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Active Listings</p>
                  <p className="text-3xl font-bold">{stats.activeListings}</p>
                </div>
                <CheckCircle2 className="h-10 w-10 text-[#198A00] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Views</p>
                  <p className="text-3xl font-bold">{stats.totalViews.toLocaleString()}</p>
                </div>
                <Eye className="h-10 w-10 text-[#EF7D00] opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Inquiries</p>
                  <p className="text-3xl font-bold">{stats.totalInquiries}</p>
                </div>
                <MessageCircle className="h-10 w-10 text-[#EF7D00] opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Listings Table */}
        <Card>
          <CardHeader>
            <CardTitle>My Listings</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="active">
                  Active ({mockListings.filter((l) => l.status === "active").length})
                </TabsTrigger>
                <TabsTrigger value="pending">
                  Pending ({mockListings.filter((l) => l.status === "pending").length})
                </TabsTrigger>
                <TabsTrigger value="sold">Sold ({mockListings.filter((l) => l.status === "sold").length})</TabsTrigger>
                <TabsTrigger value="all">All ({mockListings.length})</TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="space-y-4 mt-6">
                {mockListings
                  .filter((listing) => activeTab === "all" || listing.status === activeTab)
                  .map((listing) => (
                    <Card key={listing.id}>
                      <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row gap-4">
                          <img
                            src={listing.image || "/placeholder.svg"}
                            alt={listing.title}
                            className="w-full md:w-48 h-32 object-cover rounded-lg"
                          />

                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <h3 className="font-semibold text-lg">{listing.title}</h3>
                                  {listing.featured && (
                                    <Badge className="bg-[#EF7D00]">
                                      <Crown className="h-3 w-3 mr-1" />
                                      Featured
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-2xl font-bold text-[#198A00]">
                                  ZMW {listing.price.toLocaleString()}
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                {getStatusBadge(listing.status)}
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon">
                                      <MoreVertical className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem>
                                      <Eye className="h-4 w-4 mr-2" />
                                      View Listing
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Edit className="h-4 w-4 mr-2" />
                                      Edit
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <RefreshCw className="h-4 w-4 mr-2" />
                                      Boost to Top
                                    </DropdownMenuItem>
                                    <DropdownMenuItem className="text-destructive">
                                      <Trash2 className="h-4 w-4 mr-2" />
                                      Delete
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div className="flex items-center gap-2">
                                <Eye className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium">{listing.views.toLocaleString()}</span>
                                <span className="text-muted-foreground">views</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <MessageCircle className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium">{listing.inquiries}</span>
                                <span className="text-muted-foreground">inquiries</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Heart className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium">{listing.favorites}</span>
                                <span className="text-muted-foreground">favorites</span>
                              </div>
                            </div>

                            <p className="text-sm text-muted-foreground mt-2">
                              Listed on {new Date(listing.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                {mockListings.filter((listing) => activeTab === "all" || listing.status === activeTab).length === 0 && (
                  <div className="text-center py-12">
                    <Car className="h-16 w-16 mx-auto text-muted-foreground mb-4 opacity-20" />
                    <h3 className="font-semibold text-lg mb-2">No listings found</h3>
                    <p className="text-muted-foreground mb-4">You don't have any {activeTab} listings yet.</p>
                    <Button className="bg-[#198A00] hover:bg-[#157000]" asChild>
                      <Link href="/sell">
                        <Plus className="h-4 w-4 mr-2" />
                        Create Your First Listing
                      </Link>
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

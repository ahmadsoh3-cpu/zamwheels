"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Car,
  TrendingUp,
  DollarSign,
  Eye,
  MessageCircle,
  ShoppingCart,
  BarChart3,
  Upload,
  Plus,
  Download,
} from "lucide-react"
import { MainNav } from "@/components/main-nav"
import {
  Bar,
  BarChart,
  Line,
  LineChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

const salesData = [
  { month: "Jan", sales: 12, revenue: 3400000 },
  { month: "Feb", sales: 15, revenue: 4200000 },
  { month: "Mar", sales: 18, revenue: 5100000 },
  { month: "Apr", sales: 22, revenue: 6300000 },
  { month: "May", sales: 25, revenue: 7200000 },
  { month: "Jun", sales: 28, revenue: 8100000 },
]

const inventoryAging = [
  { range: "0-30 days", count: 45 },
  { range: "31-60 days", count: 32 },
  { range: "61-90 days", count: 18 },
  { range: "90+ days", count: 12 },
]

export default function DealerDashboard() {
  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Dealer Dashboard</h1>
            <p className="text-muted-foreground">Premium Motors Zambia</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline">
              <Upload className="h-4 w-4 mr-2" />
              Bulk Upload
            </Button>
            <Button className="bg-[#198A00] hover:bg-[#157000]">
              <Plus className="h-4 w-4 mr-2" />
              Add Vehicle
            </Button>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Total Inventory</p>
                <Car className="h-5 w-5 text-[#198A00]" />
              </div>
              <p className="text-3xl font-bold mb-1">107</p>
              <p className="text-sm text-[#198A00] flex items-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +12 this month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Active Listings</p>
                <Eye className="h-5 w-5 text-[#198A00]" />
              </div>
              <p className="text-3xl font-bold mb-1">95</p>
              <p className="text-sm text-muted-foreground">12 sold this month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Total Inquiries</p>
                <MessageCircle className="h-5 w-5 text-[#EF7D00]" />
              </div>
              <p className="text-3xl font-bold mb-1">342</p>
              <p className="text-sm text-[#198A00] flex items-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +28% vs last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                <DollarSign className="h-5 w-5 text-[#EF7D00]" />
              </div>
              <p className="text-3xl font-bold mb-1">8.1M</p>
              <p className="text-sm text-[#198A00] flex items-center">
                <TrendingUp className="h-3 w-3 mr-1" />
                +15% vs last month
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Sales Performance */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Sales Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="revenue">
                <TabsList>
                  <TabsTrigger value="revenue">Revenue</TabsTrigger>
                  <TabsTrigger value="units">Units Sold</TabsTrigger>
                </TabsList>
                <TabsContent value="revenue" className="mt-4">
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="revenue" stroke="#198A00" strokeWidth={2} name="Revenue (ZMW)" />
                    </LineChart>
                  </ResponsiveContainer>
                </TabsContent>
                <TabsContent value="units" className="mt-4">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="sales" fill="#198A00" name="Units Sold" />
                    </BarChart>
                  </ResponsiveContainer>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start bg-transparent" variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add New Vehicle
              </Button>
              <Button className="w-full justify-start bg-transparent" variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Bulk Import CSV
              </Button>
              <Button className="w-full justify-start bg-transparent" variant="outline">
                <BarChart3 className="h-4 w-4 mr-2" />
                View Full Analytics
              </Button>
              <Button className="w-full justify-start bg-transparent" variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export Reports
              </Button>
              <Button className="w-full justify-start bg-[#EF7D00] hover:bg-[#d67000] text-white">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Buy Promotion Package
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Inventory Aging */}
          <Card>
            <CardHeader>
              <CardTitle>Inventory Aging</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={inventoryAging}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="range" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#EF7D00" name="Vehicles" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Performing Models */}
          <Card>
            <CardHeader>
              <CardTitle>Top Performing Models</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { model: "Toyota Hilux", sold: 8, revenue: 3600000 },
                  { model: "Nissan Patrol", sold: 5, revenue: 3750000 },
                  { model: "Honda CR-V", sold: 6, revenue: 1680000 },
                  { model: "Mazda CX-5", sold: 4, revenue: 980000 },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-semibold">{item.model}</p>
                      <p className="text-sm text-muted-foreground">{item.sold} units sold</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-[#198A00]">ZMW {(item.revenue / 1000000).toFixed(1)}M</p>
                      <p className="text-sm text-muted-foreground">revenue</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
